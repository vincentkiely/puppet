require 'spec_helper'
describe 'virtu' do

  context 'with defaults for all parameters' do
    it { should contain_class('virtu') }
  end
end
